﻿namespace KundeApp2.DAL
{
    internal class log
    {
    }
}